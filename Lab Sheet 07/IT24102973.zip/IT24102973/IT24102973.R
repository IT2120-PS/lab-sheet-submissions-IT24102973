setwd("C:\\Users\\HP PC\\Desktop\\IT24102973")
getwd()

---(01)----
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

---(02)---
  pexp(2, rate = 1/3)

---(03)---
  1 - pnorm(130, mean = 100, sd = 15) 

---(04)---
  qnorm(0.95, mean = 100, sd = 15)