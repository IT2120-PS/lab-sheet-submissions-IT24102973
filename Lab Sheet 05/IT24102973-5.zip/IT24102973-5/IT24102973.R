setwd("C:\\Users\\it24102973\\Downloads\\Lab 05-20250829")
getwd()

data<- read.table("Exercise - Lab 05.txt",header = TRUE,sep = ",")
fix(data)

names(data)<-c("Time")
attach(data)

##Part 02

hist(Time,main = "Delivery_Time_minutes")
histogram<-hist(Time,main = "Delivery_Time_minutes",breaks =  seq(20, 70, length = 9), right =  TRUE)
histogram<-hist(Time,main = "Delivery_Time_minutes",breaks =  seq(20, 70, length = 9), right =  FALSE)

##Part 03 
##If the bars are tall in the middle and taper on both sides → symmetric (bell-shaped).
##If the bars are higher on the left, tail to the right → positively skewed.
##If the bars are higher on the right, tail to the left → negatively skewed.

##Part 04

# Cumulative frequency
cumfreq <- cumsum(histogram$counts)

# Class boundaries (upper limits of intervals)
class_boundaries <- histogram$breaks[-1]

# Plot Ogive
plot(class_boundaries, cumfreq,
     type = "o", col = "blue",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cumfreq)))


